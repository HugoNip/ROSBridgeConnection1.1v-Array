//
// Created by julian on 08.01.19.
//

#include <rbc/msgs/nav_msgs/map_meta_data.h>

using namespace rbc::msgs::nav_msgs;
