#!/usr/bin/env bash
source /opt/ros/kinetic/setup.bash
roslaunch rosbridge_server rosbridge_websocket.launch
