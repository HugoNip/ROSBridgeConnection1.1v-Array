//
// Created by Julian on 15.10.18.
//

#ifndef ROSBRIDGECLIENT_RBC_SUBSCRIBERS_H
#define ROSBRIDGECLIENT_RBC_SUBSCRIBERS_H

#include <rbc/subscriber/rbc_string_subscriber.h>
#include <rbc/subscriber/rbc_accel_subscriber.h>

#endif //ROSBRIDGECLIENT_RBC_SUBSCRIBERS_H
